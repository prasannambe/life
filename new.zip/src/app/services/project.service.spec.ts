import { HttpClientModule } from '@angular/common/http';
import { TestBed, inject, fakeAsync, tick } from '@angular/core/testing';
import { of } from 'rxjs';

import { ProjectService } from './project.service';
import { ApiService } from 'src/app/services/api.service';

describe('ProjectService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientModule],
    providers: [ProjectService, ApiService]
  }));

  it('should be created', () => {
    const service: ProjectService = TestBed.get(ProjectService);
    expect(service).toBeTruthy();
  });
});
