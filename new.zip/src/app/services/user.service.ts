import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { ApiService } from './api.service';
import { User } from 'src/app/models/UserModel';


@Injectable({ providedIn: 'root'})

export class UserService 
{

constructor(private apiService: ApiService) { }

create(user: User): Observable<any> {
  return this.apiService.post("User/InsertUser", user);   
}

update(user: User): Observable<any> {
  return this.apiService.put("User/UpdateUser", user);
}

delete(userId: number) {
  return this.apiService.delete("User/DeleteUser", new HttpParams().set("id", userId.toString()))
}

getAll(): Observable<any> {
  return this.apiService.get("User/GetAllUser")
    .pipe(map((users: Array<any>) => users.map(user => this.mapUser(user))));
}

getById(userId: number): Observable<any> {
    return this.apiService.get("User/GetUserById", new HttpParams().set("id", userId.toString()))
    .pipe(map(user => this.mapUser(user)));
} 

private mapUser(user): User { 
  return {
    UserId : user.UserId,
    FirstName : user.FirstName,
    LastName : user.LastName, 
    EmployeeId : user.EmployeeId,
    TaskId : user.TaskId,
    ProjectId: user.ProjectId 
  };

}
}
