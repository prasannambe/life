import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { ApiService } from './api.service';
import { ParentTask } from 'src/app/models/ParentTaskModel';


@Injectable({ providedIn: 'root'})

export class ParenttaskService {

  constructor(private apiService: ApiService) { }

create(parenttask: ParentTask): Observable<any> {
  return this.apiService.post("ParentTask/InsertParentTask", parenttask);   
}

update(parenttask: ParentTask): Observable<any> {
  return this.apiService.put("ParentTask/UpdateParentTask", parenttask);
}

delete(Id: number) {
  return this.apiService.delete("ParentTask/DeleteParentTask", new HttpParams().set("id", Id.toString()))
}

getAll(): Observable<any> {
  return this.apiService.get("ParentTask/GetAllParentTask")
    .pipe(map((Ptask: Array<any>) => Ptask.map(PT => this.mapUser(PT))));
}

getById(Id: number): Observable<any> {
    return this.apiService.get("ParentTask/GetParentTaskById", new HttpParams().set("id", Id.toString()))
    .pipe(map(pTask => this.mapUser(pTask)));
} 

private mapUser(parenttask): ParentTask { 
  return {
    ParentTaskId : parenttask.ParentTaskId,
    ParentTaskName : parenttask.ParentTaskName,
    ParentTask : parenttask.ParentTask,     
  };

}
}
