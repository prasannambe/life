import { HttpClientModule } from '@angular/common/http';
import { TestBed, inject, fakeAsync, tick } from '@angular/core/testing';
import { of } from 'rxjs';

import { UserService } from './user.service';
import { ApiService } from 'src/app/services/api.service';

describe('UserService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientModule],
    providers: [UserService, ApiService]
  }));


  it('should be created', () => {
    const service: UserService = TestBed.get(UserService);
    expect(service).toBeTruthy();
  });
});
