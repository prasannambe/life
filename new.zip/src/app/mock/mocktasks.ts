import { User } from "../models/UserModel";
import { ParentTask } from "../models/ParentTaskModel";
import { Task } from "../models/TaskModel";
import { Project } from "../models/ProjectModel";

export const lstUsers: User[] = 
[
    { UserId: 1, FirstName: "mockFirstName1", LastName: "mockLastName1" , EmployeeId: 1234561, ProjectId: 5551, TaskId: 4311},
    { UserId: 2, FirstName: "mockFirstName2", LastName: "mockLastName2" , EmployeeId: 1234562, ProjectId: 5552, TaskId: 4312},
    { UserId: 3, FirstName: "mockFirstName3", LastName: "mockLastName3" , EmployeeId: 1234563, ProjectId: 5553, TaskId: 4313},
];

export const lstParentTasks: ParentTask[] = 
[
    { ParentTaskId: 1231, ParentTaskName: "ParentTaskName1", ParentTask: "ParentTaskName1"},
    { ParentTaskId: 1232, ParentTaskName: "ParentTaskName2", ParentTask: "ParentTaskName2"},
    { ParentTaskId: 1233, ParentTaskName: "ParentTaskName3", ParentTask: "ParentTaskName3"}
];

export const lstTasks: Task[] = 
[
    {TaskId: 1231,ParentTaskId: 234, ProjectId: 5551,TaskName: "string1",StartDate: new Date(2018, 12, 12), EndDate: new Date(2019, 12, 12), Priority:55,
    Status: "Completed", Project: "Project1", ParentTask:"ParentTask1",UserId:123, UserName :"UserName1",isParentTask:true},
    {TaskId: 1232,ParentTaskId: 234, ProjectId: 5552,TaskName: "string2",StartDate: new Date(2018, 12, 12), EndDate: new Date(2019, 12, 12), Priority:65,
    Status: "Completed", Project: "Project1", ParentTask:"ParentTask2",UserId:123, UserName :"UserName2",isParentTask:true},
    {TaskId: 1233,ParentTaskId: 234, ProjectId: 5553,TaskName: "string3",StartDate: new Date(2018, 12, 12), EndDate: new Date(2019, 12, 12), Priority:75,
    Status: "Completed", Project: "Project1", ParentTask:"ParentTask3",UserId:123, UserName :"UserName3",isParentTask:true},
];


export const lstProjects: Project[] = 
[
    {ProjectId: 121,       ProjectName: "ProjectName1",        StartDate: new Date(2018, 12, 12),        EndDate: new Date(2018, 12, 12),        Priority: 75,        
    UserId: 3211,        TasksCount: 5,        CompletedTask: 5,        UserName:"UserName1" },
    {ProjectId: 122,        ProjectName: "ProjectName2",        StartDate: new Date(2018, 12, 12),        EndDate: new Date(2018, 12, 12),        Priority: 95,        
    UserId: 3212,        TasksCount: 5,        CompletedTask: 5,        UserName:"UserName2" },
    {ProjectId: 123,        ProjectName: "ProjectName3",        StartDate: new Date(2018, 12, 12),        EndDate: new Date(2018, 12, 12),        Priority: 55,        
    UserId: 3213,        TasksCount: 5,        CompletedTask: 5,        UserName:"UserName3" }
];