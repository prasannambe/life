export class ParentTask 
{
        ParentTaskId: number;
        ParentTaskName: string;
        ParentTask: string;
        
	constructor() { }
}
