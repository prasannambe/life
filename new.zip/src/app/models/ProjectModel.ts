export class Project
{
        ProjectId: number;
        ProjectName: string;
        StartDate: Date;
        EndDate: Date;
        Priority: number;
        
        UserId: number;
        TasksCount: number;
        CompletedTask: number;
        UserName:string;

	constructor() { }
}
