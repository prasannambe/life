import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';

import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { NgxPaginationModule } from 'ngx-pagination';
import { GrdFilterPipe } from './filter/grd-filter.pipe';

import { AppRoutingModule } from './route/app-routing.module';
import { AppComponent } from './app.component';
import { UserComponent } from './ui//user/user.component';
import { ProjectComponent } from './ui/project/project.component';
import { TaskComponent } from './ui/task/task.component';
import { ViewtaskComponent } from './ui/viewtask/viewtask.component';

import { ProjectService } from './services/project.service';
import { UserService } from './services/user.service';
import { ParenttaskService } from './services/parenttask.service';
import { TaskService } from './services/task.service';
import { ApiService } from './services/api.service';


@NgModule({
  declarations: [
    AppComponent,
    GrdFilterPipe,
    UserComponent,
    ProjectComponent,
    TaskComponent,
    ViewtaskComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,    
    HttpClientModule,


    AppRoutingModule,
    NgxPaginationModule,
    BsDatepickerModule.forRoot(),
    DatepickerModule.forRoot()
  ],
  providers: [ApiService,ProjectService, UserService,ParenttaskService,TaskService],
  bootstrap: [AppComponent]
})
export class AppModule { }
