import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ViewtaskComponent } from './viewtask.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { HttpClientModule } from '@angular/common/http';

import { GrdFilterPipe } from 'src/app/filter/grd-filter.pipe';

import { UserService} from 'src/app/services/user.service';
import { ProjectService} from 'src/app/services/project.service';
import { TaskService} from 'src/app/services/task.service';
import { ParenttaskService} from 'src/app/services/parenttask.service';
import { ApiService } from 'src/app/services/api.service';

import { RouterTestingModule } from '@angular/router/testing';
import { NgxPaginationModule } from 'ngx-pagination';

import { lstUsers } from 'src/app/mock/mocktasks';
import { lstParentTasks } from 'src/app/mock/mocktasks';
import { lstTasks } from 'src/app/mock/mocktasks';
import { lstProjects } from 'src/app/mock/mocktasks';

import { of } from 'rxjs';

describe('ViewtaskComponent', () => {
  let component: ViewtaskComponent;
  let fixture: ComponentFixture<ViewtaskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule, ReactiveFormsModule, BsDatepickerModule.forRoot(),
        DatepickerModule.forRoot(), HttpClientModule, RouterTestingModule, NgxPaginationModule],
      declarations: [ViewtaskComponent, GrdFilterPipe],
      providers: [TaskService, UserService, ProjectService,ParenttaskService,ApiService]
    })
      .compileComponents();
      spyOn(TaskService.prototype, 'getAll').and.returnValue(of(lstTasks));      
  }));


  beforeEach(() => {
    fixture = TestBed.createComponent(ViewtaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Should create', () => {
    expect(component).toBeTruthy();
  });

  it('Should get all tasks - view', () => {
    component.getAllTask();    
    expect(component.allTask).toEqual(lstTasks);
  });

});