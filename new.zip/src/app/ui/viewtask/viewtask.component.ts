import { Component, OnInit } from '@angular/core';

import { ProjectService} from 'src/app/services/project.service';
import { Project } from 'src/app/models/ProjectModel';

import { TaskService} from 'src/app/services/task.service';
import { Task } from 'src/app/models/TaskModel';

@Component({
  selector: 'app-viewtask',
  templateUrl: './viewtask.component.html',
  styleUrls: ['./viewtask.component.css']
})
export class ViewtaskComponent implements OnInit {

  allTask: Task[];
  allProjects: Project[];
  taskCount: number = 0;
  projectCount: number = 0;
  public searchText: string;
  projectId: number;
  display = 'none';

  constructor(private _taskService: TaskService, private _projectService: ProjectService) { }

  ngOnInit() {
    this.getAllTask();
    this.getProjects();
  }

  public getAllTask() {
    this._taskService.getAll().subscribe(
      result => {
        this.allTask = result;
        this.taskCount = result.length;
      });
  }

  private getTime(date?: Date) {return date != null ? new Date(date).getTime() : 0;
  }

  private getProjects() {
    this._projectService.getAll().subscribe(
      result => {
        this.allProjects = result;
        this.projectCount = result.length;
      });
  }

  endTask(task) 
  { 
    this._taskService.endTask(task).subscribe(result => 
      {
        alert("Task has been Completed - " + task.TaskName);
        this.getAllTask();
      });
  }


  OpenProjectModal() {
    this.display = 'block';
  }

  closeProjectModal() {
    this.display = 'none';
  }


  SelectProject(projectId, projectName) {
    this.projectId = projectId;
    this.searchText = projectName;
    this.display = 'none';
  }

  SortByProject(strType: string) {

    switch (strType) {
      case "startdate":
        this.allTask.sort((a, b) => {
          return this.getTime(a.StartDate) - this.getTime(b.StartDate);
        });
        break;
      case "enddate":
        this.allTask.sort((a, b) => {
          return this.getTime(a.EndDate) - this.getTime(b.EndDate);
        });
        break;
      case "priority":
        this.allTask.sort(function (a, b) { return a.Priority - b.Priority });
        break;
      case "completed":
        this.allTask.sort((a, b) => a.Status.localeCompare(b.Status));
        break;
    }
  }



}
