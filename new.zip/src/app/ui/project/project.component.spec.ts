import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { GrdFilterPipe } from 'src/app/filter/grd-filter.pipe';
import { NgxPaginationModule } from 'ngx-pagination';

import { UserService} from 'src/app/services/user.service';
import { ProjectService } from 'src/app/services/project.service';
import { ApiService } from 'src/app/services/api.service';
import { ProjectComponent } from './project.component';

import { lstProjects } from 'src/app/mock/mocktasks';
import { of } from 'rxjs';

describe('ProjectComponent', () => {
  let component: ProjectComponent;
  let fixture: ComponentFixture<ProjectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule, ReactiveFormsModule, BsDatepickerModule.forRoot(),
        DatepickerModule.forRoot(), HttpClientModule, NgxPaginationModule],
      declarations: [ProjectComponent, GrdFilterPipe],
      providers: [ProjectService, UserService,ApiService]
    })
      .compileComponents();
      spyOn(ProjectService.prototype, 'getAll').and.returnValue(of(lstProjects));
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('project Form invalid when empty', () => {
    expect(component.projectForm.valid).toBeFalsy();
  });

  it('Project Name field validity', () => {
    let errors = {};
    let ProjectName = component.projectForm.controls['ProjectName'];
    errors = ProjectName.errors || {};
    expect(errors['required']).toBeTruthy(); 
  });

  it('project Form valid when submitted', () => {
    expect(component.projectForm.valid).toBeFalsy();
    component.projectForm.controls['ProjectName'].setValue("Karma First");
    component.projectForm.controls['Priority'].setValue("75");
    component.projectForm.controls['StartDate'].setValue("2018-12-12");
    component.projectForm.controls['EndDate'].setValue("2019-12-12");
    expect(component.projectForm.valid).toBeTruthy();
  });

  it('should get all Projects - view', () => {
    component.GetAllProjects();    
    expect(component.allProjects).toEqual(lstProjects);
  });

});