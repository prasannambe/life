import { BrowserTransferStateModule } from "@angular/platform-browser";

export const environment = {
  production: BrowserTransferStateModule,
  api_url: "http://localhost/ProjectManagementService/Api/"
           
};
